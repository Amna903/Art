1:"$Sreact.fragment"
2:I[9827,["/_next/static/chunks/1vc0hgxtj7ph_.js","/_next/static/chunks/1q0u4e48rw59q.js","/_next/static/chunks/2ey02yml5es19.js","/_next/static/chunks/255effni_ttim.js","/_next/static/chunks/2qipzqp-l0jzs.js"],"default"]
3:I[79983,["/_next/static/chunks/1vc0hgxtj7ph_.js","/_next/static/chunks/1q0u4e48rw59q.js","/_next/static/chunks/2ey02yml5es19.js","/_next/static/chunks/255effni_ttim.js","/_next/static/chunks/2qipzqp-l0jzs.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":4294967294,"varyParams":"$W4","buildId":"ZaMM1pzwL0l7AEeRv0yt1"}
